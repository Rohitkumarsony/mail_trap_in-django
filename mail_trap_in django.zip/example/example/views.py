from django.shortcuts import render
from django.core.mail import send_mail
from django.http import HttpResponse

def simple(request):
    send_mail(subject='hii',
              message='that your message',
              from_email='mailtrap@rohit.com',
              recipient_list=['rohitkrsoni1234567@gmail.com'])
    return HttpResponse ("successfully send")